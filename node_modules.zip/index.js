// -*- coding: utf-8 -*-

// Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
// SPDX-License-Identifier: LicenseRef-.amazon.com.-AmznSL-1.0
// Licensed under the Amazon Software License (the "License")
// You may not use this file except in compliance with the License.
// A copy of the License is located at http://aws.amazon.com/asl/
//
// This file is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific
// language governing permissions and limitations under the License.

const https = require('https');

exports.handler = function (request, context) {
    if (request.directive.header.namespace === 'Alexa.Discovery' && request.directive.header.name === 'Discover') {
        log("DEBUG:", "Discover request",  JSON.stringify(request));
        handleDiscovery(request, context, "");
    }
    else if (request.directive.header.namespace === 'Alexa.PowerController') {
        if (request.directive.header.name === 'TurnOn' || request.directive.header.name === 'TurnOff') {
            log("DEBUG:", "TurnOn or TurnOff Request", JSON.stringify(request));
            handlePowerControl(request, context);
        }
    }
    else if (request.directive.header.namespace === 'Alexa.Authorization' && request.directive.header.name === 'AcceptGrant') {
        handleAuthorization(request, context)
    }
    else if (request.directive.header.namespace === 'Alexa.ContactSensor') {
        if (request.directive.header.name === 'Dhanu') {
            log("DEBUG:", "ChangeReport Request2", JSON.stringify(request));
            handleChangeReport2(request, context);
        }
    }
    else if (request.directive.header.namespace === 'Alexa.ContactSensor') {
        if (request.directive.header.name === 'StateReport') {
            log("DEBUG:", "StateReport Request", JSON.stringify(request));
            handleStateReport(request, context);
        }
    }
    else if (request.directive.header.namespace === 'Alexa.ContactSensor') {
        if (request.directive.header.name === 'ChangeReport') {
            log("DEBUG:", "ChangeReport Request", JSON.stringify(request));
            handleChangeReport(request, context);
        }
    }
   
    
    function handleAuthorization(request, context) {
        // Send the AcceptGrant response
        var payload = {};
        var header = request.directive.header;
        header.name = "AcceptGrant.Response";
        console.log("DEBUG", "AcceptGrant Response: ", JSON.stringify({ header: header, payload: payload }));
        context.succeed({ event: { header: header, payload: payload } });
    }

    function handleDiscovery(request, context) {
        // Send the discovery response
        var payload = {
            "endpoints":
            [
                {
                    "endpointId": "sample-bulb-01",
                    "manufacturerName": "Smart Device Company",
                    "friendlyName": "Livingroom lamp",
                    "description": "Virtual smart light bulb",
                    "displayCategories": ["LIGHT"],
                    "additionalAttributes":  {
                        "manufacturer" : "Sample Manufacturer",
                        "model" : "Sample Model",
                        "serialNumber": "U11112233456",
                        "firmwareVersion" : "1.24.2546",
                        "softwareVersion": "1.036",
                        "customIdentifier": "Sample custom ID"
                    },
                    "cookie": {
                        "key1": "arbitrary key/value pairs for skill to reference this endpoint.",
                        "key2": "There can be multiple entries",
                        "key3": "but they should only be used for reference purposes. ",
                        "key4": "This is not a suitable place to maintain current endpoint state."
                    },
                    "capabilities":
                    [
                        {
                            "interface": "Alexa.PowerController",
                            "version": "3",
                            "type": "AlexaInterface",
                            "properties": {
                                "supported": [{
                                    "name": "powerState"
                                }],
                                 "retrievable": true
                            }
                        },
                        {
                          "type": "AlexaInterface",
                          "interface": "Alexa.ContactSensor",
                          "version": "3",
                          "properties": {
                            "supported": [
                              {
                                "name": "detectionState"
                              }
                            ],
                            "proactivelyReported": true,
                            "retrievable": true
                          }
                        },
                        {
                        "type": "AlexaInterface",
                        "interface": "Alexa.EndpointHealth",
                        "version": "3.2",
                        "properties": {
                            "supported": [{
                                "name": "connectivity"
                            }],
                            "retrievable": true
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa",
                        "version": "3"
                    }
                    ]
                }
            ]
        };
        var header = request.directive.header;
        header.name = "Discover.Response";
        log("DEBUG", "Discovery Response: ", JSON.stringify({ header: header, payload: payload }));
        context.succeed({ event: { header: header, payload: payload } });
    }

    function log(message, message1, message2) {
        console.log(message + message1 + message2);
    }

    function handlePowerControl(request, context) {
        // get device ID passed in during discovery
        var requestMethod = request.directive.header.name;
        var responseHeader = request.directive.header;
        responseHeader.namespace = "Alexa";
        responseHeader.name = "Response";
        responseHeader.messageId = responseHeader.messageId + "-R";
        // get user token pass in request
        var requestToken = request.directive.endpoint.scope.token;
        console.log('Anuja ', requestToken);
        var powerResult;

        if (requestMethod === "TurnOn") {

            // Make the call to your device cloud for control
            // powerResult = stubControlFunctionToYourCloud(endpointId, token, request);
            powerResult = "ON";
        }
       else if (requestMethod === "TurnOff") {
            // Make the call to your device cloud for control and check for success
            // powerResult = stubControlFunctionToYourCloud(endpointId, token, request);
            powerResult = "OFF";
        }
        // Return the updated powerState.  Always include EndpointHealth in your Alexa.Response
        // Datetime format for timeOfSample is ISO 8601, `YYYY-MM-DDThh:mm:ssZ`.
        var contextResult = {
            "properties": [{
                "namespace": "Alexa.PowerController",
                "name": "powerState",
                "value": powerResult,
                "timeOfSample": "2022-09-03T16:20:50.52Z", //retrieve from result.
                "uncertaintyInMilliseconds": 50
            },
            {
                "namespace": "Alexa.EndpointHealth",
                "name": "connectivity",
                "value": {
                "value": "OK"
            },
            "timeOfSample": "2022-09-03T22:43:17.877738+00:00",
            "uncertaintyInMilliseconds": 0
            }]
        };
        var response = {
            context: contextResult,
            event: {
                header: responseHeader,
                endpoint: {
                    scope: {
                        type: "BearerToken",
                        token: requestToken
                    },
                    endpointId: "sample-bulb-01"
                },
                payload: {}
            }
        };
        log("DEBUG", "Alexa.PowerController ", JSON.stringify(response));
        context.succeed(response);
    }

    function handleStateReport(request, context) {
        // get device ID passed in during discovery
        var responseHeader = request.directive.header;
        responseHeader.namespace = "Alexa";
        responseHeader.name = "StateReport";
        responseHeader.messageId = responseHeader.messageId + "-R";
        // get user token pass in request
        var requestToken = request.directive.endpoint.scope.token;

        // Return the updated powerState.  Always include EndpointHealth in your Alexa.Response
        // Datetime format for timeOfSample is ISO 8601, `YYYY-MM-DDThh:mm:ssZ`.
        var contextResult = {
            "properties": [{
                "namespace": "Alexa.ContactSensor",
                "name": "detectionState",
                "value": "DETECTED",
                "timeOfSample": "2017-02-03T16:20:50.52Z",
                "uncertaintyInMilliseconds": 0
             },
            {
                "namespace": "Alexa.EndpointHealth",
                "name": "connectivity",
                "value": {
                "value": "OK"
            },
            "timeOfSample": "2022-09-03T22:43:17.877738+00:00",
            "uncertaintyInMilliseconds": 0
            }]
        };
        var response = {
            context: contextResult,
            event: {
                header: responseHeader,
                endpoint: {
                    scope: {
                        type: "BearerToken",
                        token: requestToken
                    },
                    endpointId: "sample-bulb-01"
                },
                payload: {}
            }
        };
        log("DEBUG", "Alexa.ContactSensor ", JSON.stringify(response));
        context.succeed(response);
    }

    function handleChangeReport(request, context) {
        // get device ID passed in during discovery
        var responseHeader = request.directive.header;
        responseHeader.namespace = "Alexa";
        responseHeader.name = "ChangeReport";
        responseHeader.messageId = responseHeader.messageId + "-R";
        // get user token pass in request
        var requestToken = request.directive.endpoint.scope.token;

        // Return the updated powerState.  Always include EndpointHealth in your Alexa.Response
        // Datetime format for timeOfSample is ISO 8601, `YYYY-MM-DDThh:mm:ssZ`.
        var contextResult = {
            "properties": [
            {
                "namespace": "Alexa.EndpointHealth",
                "name": "connectivity",
                "value": {
                "value": "OK"
            },
            "timeOfSample": "2022-09-03T22:43:17.877738+00:00",
            "uncertaintyInMilliseconds": 0
            }]
        };
        var response = {
            context: contextResult,
            event: {
                header: responseHeader,
                endpoint: {
                    scope: {
                        type: "BearerToken",
                        token: requestToken
                    },
                    endpointId: "sample-bulb-01"
                },
                payload: {
                  "change": {
                    "cause": {
                      "type": "PHYSICAL_INTERACTION"
                    },
                    "properties": [
                      {
                        "namespace": "Alexa.ContactSensor",
                        "name": "detectionState",
                        "value": "DETECTED",
                        "timeOfSample": "2018-02-03T16:20:50.52Z",
                        "uncertaintyInMilliseconds": 0
                      }
                    ]
                  }
                }
            }
        };
        log("DEBUG", "Alexa.ContactSensor ", JSON.stringify(response));
        context.succeed(response);
    }

    function handleChangeReport2(request, context) {
        const host_name = 'api.amazon.com';
        const host_path = '/auth/o2/token';
        const client_id = 'amzn1.application-oa2-client.d51e1ab8e3ed460d8924f8d335ce2fd7';
        const client_secret = 'amzn1.oa2-cs.v1.5341d4c19f87e2464e8223f9703a68c55471ca758756b58dd9498e73cc1059dd';
        const post_data = JSON.stringify({
            'grant_type': 'client_credentials',
            'client_id': 'amzn1.application-oa2-client.d51e1ab8e3ed460d8924f8d335ce2fd7',
            'client_secret': 'amzn1.oa2-cs.v1.5341d4c19f87e2464e8223f9703a68c55471ca758756b58dd9498e73cc1059dd',
            'scope': 'appstore::apps:readwrite'
        });

        const options = {
          hostname: host_name,
          port: 80,
          path: host_path,
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
            'Content-Length': Buffer.byteLength(post_data)
          }
        };
        
        log("DEBUG:", "Starting: ", JSON.stringify('Starting'));

        const req = https.request(options, (res) => {
            console.log(`STATUS: ${res.statusCode}`);
            console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
            res.setEncoding('utf8');
            res.on('data', (chunk) => {
                console.log(`BODY: ${chunk}`);
            });
        
            res.on('end', () => {
                console.log('No more data in response.');
            });
        });
        
        req.on('error', (e) => {
            console.error(`problem with request: ${e.message}`);
        });

        req.write(post_data);
        
        // Ending the request
        req.end();

        
        log("DEBUG:", "Ending: ", JSON.stringify(req));

        // get device ID passed in during discovery
        // var responseHeader = request.directive.header;
        // responseHeader.namespace = "Alexa";
        // responseHeader.name = "ChangeReport";
        // responseHeader.messageId = responseHeader.messageId + "-R";
        // // get user token pass in request
        // var requestToken = request.directive.endpoint.scope.token;

        // // Return the updated powerState.  Always include EndpointHealth in your Alexa.Response
        // // Datetime format for timeOfSample is ISO 8601, `YYYY-MM-DDThh:mm:ssZ`.
        // var contextResult = {
        //     "properties": [
        //     {
        //         "namespace": "Alexa.EndpointHealth",
        //         "name": "connectivity",
        //         "value": {
        //         "value": "OK"
        //     },
        //     "timeOfSample": "2022-09-03T22:43:17.877738+00:00",
        //     "uncertaintyInMilliseconds": 0
        //     }]
        // };
        // var response = {
        //     context: contextResult,
        //     event: {
        //         header: responseHeader,
        //         endpoint: {
        //             scope: {
        //                 type: "BearerToken",
        //                 token: requestToken
        //             },
        //             endpointId: "sample-bulb-01"
        //         },
        //         payload: {
        //           "change": {
        //             "cause": {
        //               "type": "PHYSICAL_INTERACTION"
        //             },
        //             "properties": [
        //               {
        //                 "namespace": "Alexa.ContactSensor",
        //                 "name": "detectionState",
        //                 "value": "DETECTED",
        //                 "timeOfSample": "2018-02-03T16:20:50.52Z",
        //                 "uncertaintyInMilliseconds": 0
        //               }
        //             ]
        //           }
        //         }
        //     }
        // };
        // log("DEBUG", "Alexa.ContactSensor ", JSON.stringify(response));
        // context.succeed(response);
    }
};
